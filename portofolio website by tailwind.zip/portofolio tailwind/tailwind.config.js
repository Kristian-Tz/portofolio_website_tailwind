/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['index.html'],
  darkMode: 'class',
  theme: {
    container: {
      center: true,
      padding: '16px'
    },
    extend: {
      colors: {
        primary: '#0d9488',
        dark: '#0f172a'  ,
        biru: '#0891b2',
        merah:'#dc2626',
        secondary: '#475569',
        ski: '#0284c7',
        kuning: '#f59e0b',
        oren:'#f97316',
      },
      screens: {
        '2xl' : '1320px'
      }
    },
  },
  plugins: [],
}

